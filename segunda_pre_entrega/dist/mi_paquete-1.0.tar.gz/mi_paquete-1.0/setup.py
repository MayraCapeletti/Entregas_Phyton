from setuptools import setup

setup(

    name="mi_paquete",
    version="1.0",
    description="estamos haciendo el primer paquete distribuible",
    author="Clase 14 Coder-Python",
    author_email="mayracapeletti@gmail.com",

    packages=["mi_paquete"]
)
